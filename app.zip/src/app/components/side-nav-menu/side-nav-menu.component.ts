import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'analytics-hub-side-nav-menu',
  templateUrl: './side-nav-menu.component.html',
  styleUrls: ['./side-nav-menu.component.scss'],
})
export class SideNavMenuComponent {
  constructor(private router: Router) {}

  getContactUsLink(a: number, b: number): string {
    return this.router
      .createUrlTree(['/contact-us'], { queryParams: { a, b } })
      .toString();
  }

  navigateToContactUs(a: number, b: number): void {
    this.router.navigate(['/contact-us'], { queryParams: { a, b } });
  }
}

import { Component, EventEmitter, Output } from '@angular/core';
// import { MatButtonModule } from '@angular/material/button';
// import { MatSidenavModule } from '@angular/material/sidenav';

@Component({
  selector: 'analytics-hub-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  // imports: [MatSidenavModule, MatButtonModule],
})
export class HeaderComponent {
  showFiller = false;
  @Output() menuClick = new EventEmitter();
  constructor() {}

  menuClicked() {
    this.menuClick.emit();
  }
}

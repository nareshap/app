import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'analytics-hub-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss'],
})
export class ContactUsComponent implements OnInit {
  constructor(private route: ActivatedRoute, private router: Router) {}

  public A: any;
  public B: any;

  ngOnInit() {
    this.route.queryParamMap.subscribe((params) => {
      const a = params.get('a');
      const b = params.get('b');
      this.A = params.get('a');
      this.B = params.get('b');
      console.log('Value of a:', a);
      console.log('Value of b:', b);
      // Perform API actions with a and b dynamic values here
    });
  }
}

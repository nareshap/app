import { AppComponent } from './app/app.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { HeaderComponent } from './header/header.component';
import { SideNavComponent } from './side-nav/side-nav.component';
import { SideNavMenuComponent } from './side-nav-menu/side-nav-menu.component';
import { ProductComponent } from './product/product.component';
import { GridEditFormComponent } from './product/edit-form.component';

export const components: any[] = [
  AppComponent,
  ContactUsComponent,
  HeaderComponent,
  SideNavComponent,
  SideNavMenuComponent,
  ProductComponent,
  GridEditFormComponent,
];

export * from './app/app.component';
export * from './header/header.component';
export * from './side-nav/side-nav.component';
export * from './side-nav-menu/side-nav-menu.component';
export * from './contact-us/contact-us.component';
export * from './product/product.component';
export * from './product/edit-form.component';

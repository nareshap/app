import { Observable } from 'rxjs';
import { Component, OnInit, Inject } from '@angular/core';

import {
  GridDataResult,
  AddEvent,
  RemoveEvent,
} from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { NotificationService } from '@progress/kendo-angular-notification';

import { Product } from './model';
import { EditService } from './edit.service';

import { map } from 'rxjs/operators';

@Component({
  selector: 'analytics-hub-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
})
export class ProductComponent implements OnInit {
  public view!: Observable<GridDataResult>;
  public gridState: State = {
    sort: [],
    skip: 0,
    take: 10,
  };

  public editDataItem!: Product | undefined;
  public isNew!: boolean;
  // private editService;

  // constructor(@Inject(EditService) editServiceFactory: () => EditService) {
  //   this.editService = editServiceFactory();
  // }

  constructor(
    public editService: EditService,
    private notificationService: NotificationService
  ) {
    // this.editService = editServiceFactory();
  }

  public ngOnInit(): void {
    this.view = this.editService.pipe(
      map((data: any[]) => {
        return process(data, this.gridState);
      })
    );

    this.editService.read();
  }

  public onStateChange(state: State): void {
    this.gridState = state;

    this.editService.read();
  }

  public addHandler(): void {
    this.editDataItem = new Product();
    this.isNew = true;
  }

  public editHandler(args: AddEvent): void {
    this.editDataItem = args.dataItem;
    this.isNew = false;
  }

  public cancelHandler(): void {
    this.editDataItem = undefined;
  }

  public saveHandler(product: Product): void {
    this.editService.save([product], this.isNew);

    this.editDataItem = undefined;
  }

  public removeHandler(args: RemoveEvent): void {
    this.notificationService.show({
      content: 'Your data has been saved. Time for tea!',
      cssClass: 'button-notification',
      animation: { type: 'slide', duration: 400 },
      position: { horizontal: 'center', vertical: 'bottom' },
      type: { style: 'success', icon: true },
      // closable: true,
      hideAfter: 2000,
    });
    // this.editService.remove(args.dataItem);
  }
}

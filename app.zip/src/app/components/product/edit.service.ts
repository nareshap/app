import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Product } from './model';
import { tap, map } from 'rxjs/operators';

import {
  DialogService,
  DialogRef,
  DialogCloseResult,
} from '@progress/kendo-angular-dialog';

const CREATE_ACTION = 'create';
const UPDATE_ACTION = 'update';
const REMOVE_ACTION = 'destroy';

@Injectable({
  providedIn: 'root',
})
export class EditService extends BehaviorSubject<Product[]> {
  constructor(private http: HttpClient, public dialogService: DialogService) {
    super([]);
  }

  private data: Product[] = [];

  public read(): void {
    if (this.data.length) {
      return super.next(this.data);
    }

    this.fetch()
      .pipe(
        tap((data) => {
          this.data = data;
        })
      )
      .subscribe((data) => {
        super.next(data);
      });
  }

  public save(data: Product[], isNew?: boolean): void {
    const action = isNew ? CREATE_ACTION : UPDATE_ACTION;

    this.reset();
    this.fetch('update', data);

    this.fetch(action, data).subscribe(
      () => this.read(),
      () => this.read()
    );
  }

  public remove(data: Product[]): void {
    this.reset();

    this.fetch(REMOVE_ACTION, data).subscribe(
      () => this.read(),
      () => this.read()
    );
    const dialog: DialogRef = this.dialogService.open({
      title: 'Please confirm',
      content: 'Are you sure?',
      actions: [{ text: 'No' }, { text: 'Yes', themeColor: 'primary' }],
      width: 450,
      height: 200,
      minWidth: 250,
    });
  }

  public resetItem(dataItem: Product): void {
    if (!dataItem) {
      return;
    }

    // find orignal data item
    const originalDataItem = this.data.find(
      (item) => item.ProductID === dataItem.ProductID
    );

    // revert changes
    // Object.assign(originalDataItem, dataItem); //<-------------------

    super.next(this.data);
  }

  private reset() {
    this.data = [];
  }

  private fetch(action = '', data?: Product[]): Observable<any> {
    switch (action) {
      case 'update':
        return this.http.post(
          'https://crudcrud.com/api/0a64d697612341908b3a749d0944660b/unicorns',
          { name: 'Sparkle Angel', age: 2, colour: 'blue' }
        );
        break;
      default:
        return this.http
          .jsonp(
            `https://demos.telerik.com/kendo-ui/service/Products/${action}?${this.serializeModels(
              data
            )}`,
            'callback'
          )
          .pipe(map((res) => <Product[]>res));
    }
  }

  private serializeModels(data?: Product[]): string {
    return data ? `&models=${JSON.stringify([data])}` : '';
  }
}

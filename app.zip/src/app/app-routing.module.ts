import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import * as fromComponents from './components';

const routes: Routes = [
  {
    path: 'contact-us',
    component: fromComponents.ContactUsComponent,
  },
  {
    path: 'products',
    component: fromComponents.ProductComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
